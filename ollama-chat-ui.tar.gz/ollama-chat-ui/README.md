# Ollama Chat UI

A modern, responsive chat UI for interacting with Ollama models, enhanced with RAG capabilities. Built with React, Tailwind CSS, and Vite.

## Features

- Chat with Ollama models via a clean, responsive interface
- Model selection and management
- Persistent chat history (localStorage)
- Theme switching (light, dark, system)
- Settings modal for endpoint and API key configuration
- Markdown rendering with code block copy support

## Getting Started

### Prerequisites

- Node.js (v18+ recommended)
- npm

### Installation

1. Clone the repository:

   ```sh
   git clone <your-repo-url>
   cd ollama-chat-ui
   ```

2. Install dependencies:

   ```sh
   npm install
   ```

### Running the App

Start the development server:

```sh
npm run dev
```

Open [http://localhost:5173](http://localhost:5173) in your browser.

### Building for Production

```sh
npm run build
```

Preview the production build:

```sh
npm run preview
```

## Configuration

- **Ollama Endpoint**: Set the endpoint URL in the Settings modal (default: `http://localhost:11434`).
- **API Key**: Optionally set an API key in the Settings modal.

## Project Structure

```
public/
  index.html
src/
  App.jsx
  main.jsx
  index.css
  components/
    ChatWindow.jsx
    Sidebar.jsx
    SettingsModal.jsx
    ThemeSwitcher.jsx
tailwind.config.js
postcss.config.mjs
package.json
```

## Technologies Used

- [React](https://react.dev/)
- [Tailwind CSS](https://tailwindcss.com/)
- [Vite](https://vitejs.dev/)
- [lucide-react](https://lucide.dev/)
- [react-markdown](https://github.com/remarkjs/react-markdown)
- [uuid](https://www.npmjs.com/package/uuid)

## License

[ISC](LICENSE)