import React, { useState, useEffect } from 'react';
import Sidebar from './components/Sidebar';
import ChatWindow from './components/ChatWindow';
import SettingsModal from './components/SettingsModal';
import ThemeSwitcher from "./components/ThemeSwitcher";
import { v4 as uuidv4 } from 'uuid';

const getInitialChats = () => {
  const saved = localStorage.getItem('ollama-chats');
  if (saved) return JSON.parse(saved);
  return [{
    id: uuidv4(),
    name: 'New Chat',
    messages: [],
    model: '', // Default model will be set later
  }];
};

const App = () => {
  const [theme, setTheme] = useState(localStorage.getItem('ollama-theme') || 'system');
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [endpoint, setEndpoint] = useState(localStorage.getItem('ollama-endpoint') || '');
  const [apiKey, setApiKey] = useState(localStorage.getItem('ollama-apiKey') || '');
  const [chats, setChats] = useState(getInitialChats());
  const [activeChatId, setActiveChatId] = useState(chats[0]?.id);
  const [models, setModels] = useState([]);

  useEffect(() => {
    localStorage.setItem('ollama-chats', JSON.stringify(chats));
  }, [chats]);

  const handleSaveSettings = (newEndpoint, newApiKey) => {
    setEndpoint(newEndpoint);
    setApiKey(newApiKey);
    localStorage.setItem('ollama-endpoint', newEndpoint);
    localStorage.setItem('ollama-apiKey', newApiKey);
  };

  useEffect(() => {
    const root = document.documentElement;
    root.classList.remove('dark');
    if (theme === 'dark' || (theme === 'system' && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
      root.classList.add('dark');
    }
    localStorage.setItem('ollama-theme', theme);
  }, [theme]);

  useEffect(() => {
    if (!endpoint) return;
    fetch(`${endpoint.replace(/\/$/, '')}/api/tags`)
      .then(res => res.json())
      .then(data => setModels(data.models || []))
      .catch(() => setModels([]));
  }, [endpoint]);

  const handleNewChat = () => {
    const newChat = {
      id: uuidv4(),
      name: 'New Chat',
      messages: [],
      model: '', // Model will be set when selected
    };
    setChats([newChat, ...chats]);
    setActiveChatId(newChat.id);
  };

  const handleSelectChat = (id) => setActiveChatId(id);

  const handleDeleteChat = (id) => {
    const filtered = chats.filter(chat => chat.id !== id);
    setChats(filtered);
    if (activeChatId === id && filtered.length > 0) setActiveChatId(filtered[0].id);
  };

  const handleUpdateChat = (id, update) => {
    setChats(chats.map(chat => chat.id === id ? { ...chat, ...update } : chat));
  };

  return (
    <div className="flex flex-col h-screen w-full">
      {/* Top bar */}
      <div className="flex justify-end items-center p-2 border-b border-gray-200 dark:border-[#23272f] bg-white dark:bg-[#181a20]">
        <ThemeSwitcher theme={theme} setTheme={setTheme} />
      </div>
      <div className="flex flex-1 min-h-0">
        {/* Sidebar */}
        <Sidebar
          chats={chats}
          activeChatId={activeChatId}
          onSelectChat={handleSelectChat}
          onNewChat={handleNewChat}
          onDeleteChat={handleDeleteChat}
          onOpenSettings={() => setSettingsOpen(true)}
        />
        {/* Main chat area */}
        <main className="flex-1 flex flex-col min-h-0">
          <ChatWindow
            chat={chats.find(c => c.id === activeChatId)}
            onUpdateChat={update => handleUpdateChat(activeChatId, update)}
            models={models}
            endpoint={endpoint}
          />
        </main>
        {settingsOpen && (
          <SettingsModal
            onClose={() => setSettingsOpen(false)}
            onSave={handleSaveSettings}
            endpoint={endpoint}
            apiKey={apiKey}
          />
        )}
      </div>
    </div>
  );
};

export default App;
