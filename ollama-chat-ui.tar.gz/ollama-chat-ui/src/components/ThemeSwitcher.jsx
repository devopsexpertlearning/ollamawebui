import React from 'react';
import { Sun, Moon, Laptop } from 'lucide-react';

const ThemeSwitcher = ({ theme, setTheme }) => (
  <div className="flex gap-2 items-center">
    <button
      className={`p-2 rounded ${theme === 'light' ? 'bg-blue-100 dark:bg-blue-900' : ''}`}
      title="Light"
      onClick={() => setTheme('light')}
    >
      <Sun className="w-5 h-5" />
    </button>
    <button
      className={`p-2 rounded ${theme === 'dark' ? 'bg-blue-100 dark:bg-blue-900' : ''}`}
      title="Dark"
      onClick={() => setTheme('dark')}
    >
      <Moon className="w-5 h-5" />
    </button>
    <button
      className={`p-2 rounded ${theme === 'system' ? 'bg-blue-100 dark:bg-blue-900' : ''}`}
      title="System"
      onClick={() => setTheme('system')}
    >
      <Laptop className="w-5 h-5" />
    </button>
  </div>
);

export default ThemeSwitcher;