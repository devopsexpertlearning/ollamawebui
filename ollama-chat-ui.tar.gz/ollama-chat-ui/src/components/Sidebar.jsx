// src/components/Sidebar.jsx
import React from 'react';
import { Settings, Plus, Trash } from 'lucide-react';

const Sidebar = ({
  chats,
  activeChatId,
  onSelectChat,
  onNewChat,
  onDeleteChat,
  onOpenSettings
}) => {
  return (
    <aside className="w-full md:w-64 lg:w-72 bg-white dark:bg-[#181a20] p-4 md:p-6 shadow-lg flex flex-col h-full">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900 dark:text-blue-400 flex items-center gap-2">
          🤖 Ollama Chat
        </h1>
        <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">Enhanced with RAG capabilities</p>
      </div>
      <div className="flex-1 overflow-y-auto">
        {chats.map(chat => (
          <div
            key={chat.id}
            className={`p-2 rounded cursor-pointer flex justify-between items-center ${chat.id === activeChatId ? 'bg-blue-100 dark:bg-blue-900' : 'hover:bg-gray-100 dark:hover:bg-gray-800'}`}
            onClick={() => onSelectChat(chat.id)}
          >
            <span className="truncate text-gray-900 dark:text-white">{chat.name}</span>
            <button onClick={e => { e.stopPropagation(); onDeleteChat(chat.id); }}>
              <Trash size={14} className="text-gray-400 hover:text-red-500" />
            </button>
          </div>
        ))}
        <button onClick={onNewChat} className="mt-2 flex items-center gap-1 text-blue-600 dark:text-blue-400 hover:text-blue-800 dark:hover:text-blue-300">
          <Plus size={16} /> New Chat
        </button>
      </div>
      <div className="mt-auto flex flex-col gap-2">
        <button onClick={onOpenSettings} className="text-gray-600 dark:text-gray-300 hover:text-blue-600 dark:hover:text-blue-400 flex items-center gap-2">
          <Settings size={18} /> Settings
        </button>
      </div>
    </aside>
  );
};

export default Sidebar;
