import React, { useState, useEffect, useRef } from 'react';
import ReactMarkdown from 'react-markdown';
import { Send, Copy, XCircle } from 'lucide-react';

const CopyButton = ({ text }) => {
  const handleCopy = () => {
    navigator.clipboard.writeText(text).catch(err => {
      console.error('Error copying text: ', err);
    });
  };

  return (
    <button
      onClick={handleCopy}
      className="absolute top-1 right-1 bg-blue-600 text-white p-2 rounded"
      title="Copy to clipboard"
    >
      <Copy size={16} />
    </button>
  );
};

const ChatWindow = ({ chat, onUpdateChat, models, endpoint }) => {
  const [input, setInput] = useState('');
  const [isStreaming, setIsStreaming] = useState(false);
  const [streamedText, setStreamedText] = useState('');
  const [showScrollButton, setShowScrollButton] = useState(false);
  const [selectedModel, setSelectedModel] = useState(chat.model || '');
  const [abortController, setAbortController] = useState(null); // Added to manage the request cancellation

  const messagesEndRef = useRef(null);
  const messagesContainerRef = useRef(null);

  useEffect(() => {
    if (!showScrollButton) {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [chat.messages, streamedText, showScrollButton]);

  const handleScroll = () => {
    const container = messagesContainerRef.current;
    if (!container) return;
    const atBottom = container.scrollHeight - container.scrollTop - container.clientHeight < 40;
    setShowScrollButton(!atBottom);
  };

  if (!chat) return <div className="p-4">No chat selected.</div>;

  const handleSend = async () => {
    if (!input.trim() || isStreaming || !selectedModel) return;

    const userMessage = { sender: 'user', text: input };
    const updatedMessages = [...(chat.messages || []), userMessage];
    onUpdateChat({ messages: updatedMessages });

    setInput('');
    setIsStreaming(true);
    setStreamedText('');
    const controller = new AbortController(); // Create a new controller for cancellation
    setAbortController(controller); // Store the controller

    try {
      const response = await fetch(`${endpoint.replace(/\/$/, '')}/api/chat`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          model: selectedModel,
          messages: updatedMessages.map(m => ({
            role: m.sender === 'user' ? 'user' : 'assistant',
            content: m.text
          })),
          stream: true
        }),
        signal: controller.signal // Attach the signal to the request
      });

      if (!response.body) throw new Error('No response body');

      const reader = response.body.getReader();
      let fullText = '';
      const decoder = new TextDecoder();

      while (true) {
        const { value, done } = await reader.read();
        if (done) break;

        const chunk = decoder.decode(value, { stream: true });
        for (const line of chunk.split('\n')) {
          if (!line.trim()) continue;

          try {
            const data = JSON.parse(line);
            if (data.message && data.message.content) {
              fullText += data.message.content;
              setStreamedText(fullText); // Update the streamed text progressively
            }
          } catch (e) {
            console.error('Error parsing streamed data:', e);
          }
        }
      }

      // After streaming, update the chat with the final model response
      onUpdateChat({
        messages: [
          ...updatedMessages,
          { sender: 'bot', text: fullText }
        ]
      });
    } catch (err) {
      if (err.name === 'AbortError') {
        console.log('Request was canceled');
      } else {
        console.error('Error:', err.message);
      }

      onUpdateChat({
        messages: [
          ...updatedMessages,
          { sender: 'bot', text: 'Error: ' + err.message }
        ]
      });
    } finally {
      setIsStreaming(false);
      setStreamedText('');
      setAbortController(null); // Clear the abort controller when done
    }
  };

  const handleCancel = () => {
    if (abortController) {
      abortController.abort(); // Abort the ongoing request
    }
  };

  const handleModelChange = (e) => {
    setSelectedModel(e.target.value);
    onUpdateChat({ model: e.target.value });
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && input.trim() && !isStreaming) {
      e.preventDefault(); // Prevent default 'Enter' behavior (new line)
      handleSend();
    }
  };

  return (
    <div className="flex flex-col h-full w-full bg-white dark:bg-[#181a20] relative">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-gray-200 dark:border-gray-700 bg-white dark:bg-[#23272f] rounded-t-lg shadow-sm">
        <div className="font-bold text-lg text-gray-900 dark:text-white">{chat.name}</div>

        {/* Model selection dropdown */}
        <select
          value={selectedModel}
          onChange={handleModelChange}
          className="border border-gray-200 dark:border-gray-700 rounded px-2 py-1 bg-white text-gray-900 dark:bg-gray-700 dark:text-white light:text-gray-900"
        >
          <option value="">Select model</option>
          {models.map((model) => (
            <option key={model.name} value={model.name}>
              {model.name}
            </option>
          ))}
        </select>
      </div>

      {/* Messages */}
      <div
        className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-2"
        ref={messagesContainerRef}
        onScroll={handleScroll}
      >
        {(chat.messages || []).map((msg, idx) => (
          <div key={idx} className="flex justify-center w-full">
            <div className={`
              max-w-6xl w-full px-2 py-2 rounded-2xl relative
              ${msg.sender === 'user'
                ? 'bg-blue-500 text-white dark:bg-blue-600'
                : 'bg-gray-100 text-gray-900 dark:bg-gray-800 dark:text-white'} 
              prose prose-invert dark:prose-invert break-words
            `}>
              <ReactMarkdown>{msg.text}</ReactMarkdown>
              {msg.text.includes('```') && (
                <CopyButton text={msg.text} />
              )}
            </div>
          </div>
        ))}

        {/* Streaming assistant message */}
        {isStreaming && (
          <div className="flex justify-center w-full">
            <div className="max-w-6xl w-full px-2 py-2 rounded-2xl bg-gray-100 text-gray-900 dark:bg-gray-800 dark:text-white animate-pulse prose prose-invert dark:prose-invert break-words min-h-[48px]">
              <ReactMarkdown>{streamedText || 'Streaming...'}</ReactMarkdown>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Scroll to bottom button */}
      {showScrollButton && (
        <div className="absolute left-1/2 transform -translate-x-1/2 bottom-24 z-10">
          <button
            onClick={() => {
              messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
              setShowScrollButton(false);
            }}
            className="bg-blue-600 text-white px-4 py-2 rounded-full shadow-lg hover:bg-blue-700 transition"
          >
            Scroll to bottom
          </button>
        </div>
      )}

      {/* Input */}
      <div className="p-4 border-t border-gray-200 dark:border-gray-700 bg-white dark:bg-[#23272f] rounded-b-lg flex gap-2">
        <input
          className="flex-1 rounded-lg border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-700 text-gray-900 dark:text-white px-4 py-2"
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={handleKeyDown}  // Detect Enter key press
          placeholder="Type a message"
          disabled={isStreaming}  // Disable input during streaming
        />
        {isStreaming ? (
          <button
            onClick={handleCancel}
            className="bg-red-600 text-white rounded-lg px-4 py-2 hover:bg-red-700 transition"
          >
            <XCircle size={18} />
          </button>
        ) : (
          <button
            onClick={handleSend}
            className="bg-blue-600 text-white rounded-lg px-4 py-2 hover:bg-blue-700 transition"
            disabled={isStreaming || !input.trim()}  // Disable button during streaming
          >
            <Send size={18} />
          </button>
        )}
      </div>
    </div>
  );
};

export default ChatWindow;
