// src/components/ChatWindow.jsx
import React, { useState, useRef, useEffect } from 'react';
import { Send, Copy, Check } from 'lucide-react';
import ReactMarkdown from 'react-markdown';

const CodeBlock = ({ children }) => {
  const [copied, setCopied] = useState(false);
  const codeRef = useRef(null);

  const handleCopy = () => {
    if (codeRef.current) {
      navigator.clipboard.writeText(codeRef.current.innerText);
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    }
  };

  return (
    <div className="relative group my-2">
      <pre ref={codeRef} className="bg-[#23272f] text-white rounded-lg p-4 overflow-x-auto text-sm">
        <code>{children}</code>
      </pre>
      <button
        onClick={handleCopy}
        className="absolute top-2 right-2 bg-gray-700 text-white rounded px-2 py-1 opacity-80 hover:opacity-100 flex items-center gap-1"
        title="Copy code"
      >
        {copied ? <Check size={16} /> : <Copy size={16} />}
        <span className="text-xs">{copied ? 'Copied!' : 'Copy'}</span>
      </button>
    </div>
  );
};

const markdownComponents = {
  code({node, inline, className, children, ...props}) {
    return inline
      ? <code className="bg-gray-100 dark:bg-gray-800 rounded px-1">{children}</code>
      : <CodeBlock>{children}</CodeBlock>;
  },
  strong({node, ...props}) {
    return <strong className="bg-yellow-200 dark:bg-yellow-700 px-1 rounded">{props.children}</strong>;
  },
  em({node, ...props}) {
    return <em className="text-blue-700 dark:text-blue-300">{props.children}</em>;
  },
  p({node, ...props}) {
    return <p className="mb-2 last:mb-0">{props.children}</p>;
  }
};

const ChatWindow = ({ chat, onUpdateChat, models, endpoint }) => {
  const [input, setInput] = useState('');
  const [isStreaming, setIsStreaming] = useState(false);
  const [streamedText, setStreamedText] = useState('');
  const [showScrollButton, setShowScrollButton] = useState(false);

  const messagesEndRef = useRef(null);
  const messagesContainerRef = useRef(null);

  // Auto-scroll unless user scrolled up
  useEffect(() => {
    if (!showScrollButton) {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [chat.messages, streamedText, showScrollButton]);

  // Detect if user is not at bottom
  const handleScroll = () => {
    const container = messagesContainerRef.current;
    if (!container) return;
    const atBottom = container.scrollHeight - container.scrollTop - container.clientHeight < 40;
    setShowScrollButton(!atBottom);
  };

  if (!chat) return <div className="p-4">No chat selected.</div>;

  const handleModelChange = (e) => {
    onUpdateChat({ model: e.target.value });
  };

  const handleSend = async () => {
    if (!input.trim() || isStreaming || !chat.model) return;

    // Add user message
    const userMessage = { sender: 'user', text: input };
    const updatedMessages = [...(chat.messages || []), userMessage];
    onUpdateChat({ messages: updatedMessages });

    setInput('');
    setIsStreaming(true);
    setStreamedText('');

    // Stream from Ollama API
    try {
      const response = await fetch(
        `${endpoint.replace(/\/$/, '')}/api/chat`,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            model: chat.model,
            messages: updatedMessages.map(m => ({
              role: m.sender === 'user' ? 'user' : 'assistant',
              content: m.text
            })),
            stream: true
          })
        }
      );

      if (!response.body) throw new Error('No response body');

      const reader = response.body.getReader();
      let fullText = '';
      const decoder = new TextDecoder();

      while (true) {
        const { value, done } = await reader.read();
        if (done) break;
        const chunk = decoder.decode(value, { stream: true });
        for (const line of chunk.split('\n')) {
          if (!line.trim()) continue;
          try {
            const data = JSON.parse(line);
            if (data.message && data.message.content) {
              fullText += data.message.content;
              setStreamedText(fullText);
            }
          } catch (e) {}
        }
      }

      onUpdateChat({
        messages: [
          ...updatedMessages,
          { sender: 'bot', text: fullText }
        ]
      });
      setStreamedText('');
    } catch (err) {
      onUpdateChat({
        messages: [
          ...updatedMessages,
          { sender: 'bot', text: 'Error: ' + err.message }
        ]
      });
      setStreamedText('');
    } finally {
      setIsStreaming(false);
    }
  };

  return (
    <div className="flex flex-col h-full w-full bg-white dark:bg-[#181a20] relative">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-gray-200 dark:border-gray-700 bg-white dark:bg-[#23272f] rounded-t-lg shadow-sm">
        <div className="font-bold text-lg text-gray-900 dark:text-white">{chat.name}</div>
        <select
          value={chat.model}
          onChange={handleModelChange}
          className="border border-gray-200 dark:border-gray-700 rounded px-2 py-1 bg-white text-gray-900 dark:bg-gray-700 dark:text-white"
        >
          <option value="">Select model</option>
          {models.map(m => (
            <option key={m.name} value={m.name}>{m.name}</option>
          ))}
        </select>
      </div>
      {/* Messages */}
      <div
        className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-3"
        ref={messagesContainerRef}
        onScroll={handleScroll}
        style={{ scrollBehavior: 'smooth' }}
      >
        {(chat.messages || []).map((msg, idx) => (
          <div
            key={idx}
            className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'} w-full`}
          >
            <div className={`
              max-w-2xl w-fit px-5 py-4 rounded-2xl
              ${msg.sender === 'user'
                ? 'bg-blue-500 text-white dark:bg-blue-600'
                : 'bg-gray-100 text-gray-900 dark:bg-gray-800 dark:text-white'}
              prose prose-invert dark:prose-invert break-words
            `}>
              <ReactMarkdown components={markdownComponents}>
                {msg.text}
              </ReactMarkdown>
            </div>
          </div>
        ))}

        {/* Streaming assistant message */}
        {isStreaming && (
          <div className="flex justify-start w-full">
            <div className="max-w-2xl w-fit px-5 py-4 rounded-2xl bg-gray-100 text-gray-900 dark:bg-gray-800 dark:text-white animate-pulse prose prose-invert dark:prose-invert break-words">
              <ReactMarkdown components={markdownComponents}>
                {streamedText || '...'}
              </ReactMarkdown>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>
      {/* Scroll to bottom button */}
      {showScrollButton && (
        <div className="absolute left-1/2 transform -translate-x-1/2 bottom-24 z-10">
          <button
            onClick={() => {
              messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
              setShowScrollButton(false);
            }}
            className="bg-blue-600 text-white px-4 py-2 rounded-full shadow-lg hover:bg-blue-700 transition"
          >
            Scroll to bottom
          </button>
        </div>
      )}
      {/* Input */}
      <div className="p-4 border-t border-gray-200 dark:border-gray-700 bg-white dark:bg-[#23272f] rounded-b-lg flex gap-2">
        <input
          className="flex-1 rounded-lg border border-gray-200 dark:border-gray-700 px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white text-gray-900 dark:bg-[#181a20] dark:text-white"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Type your message..."
          onKeyDown={(e) => e.key === 'Enter' && handleSend()}
          disabled={isStreaming}
        />
        <button
          onClick={handleSend}
          className="bg-blue-600 hover:bg-blue-700 text-white p-2 rounded-lg"
          disabled={isStreaming}
        >
          <Send size={18} />
        </button>
      </div>
    </div>
  );
};

export default ChatWindow;
