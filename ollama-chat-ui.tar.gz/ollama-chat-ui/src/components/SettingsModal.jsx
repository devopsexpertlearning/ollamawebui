// src/components/SettingsModal.jsx
import React, { useState, useEffect } from 'react';

const SettingsModal = ({ onClose, onSave, endpoint: initialEndpoint, apiKey: initialApiKey }) => {
  const [endpoint, setEndpoint] = useState(initialEndpoint || '');
  const [apiKey, setApiKey] = useState(initialApiKey || '');

  // Update local state if props change (e.g., when modal is reopened)
  useEffect(() => {
    setEndpoint(initialEndpoint || '');
    setApiKey(initialApiKey || '');
  }, [initialEndpoint, initialApiKey]);

  const handleSave = () => {
    onSave(endpoint, apiKey); // pass values back to parent
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white dark:bg-gray-800 rounded-xl p-6 w-full max-w-md shadow-2xl">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-bold text-gray-900 dark:text-white">Settings</h2>
          <button onClick={onClose} className="text-gray-500 hover:text-gray-800">&times;</button>
        </div>
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-200">Ollama Endpoint</label>
            <input
              type="text"
              className="w-full mt-1 px-3 py-2 border rounded-lg dark:bg-gray-900 dark:text-white"
              placeholder="http://localhost:11434"
              value={endpoint}
              onChange={(e) => setEndpoint(e.target.value)}
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-200">API Key</label>
            <input
              type="password"
              className="w-full mt-1 px-3 py-2 border rounded-lg dark:bg-gray-900 dark:text-white"
              placeholder="Optional"
              value={apiKey}
              onChange={(e) => setApiKey(e.target.value)}
            />
          </div>
        </div>
        <div className="mt-6 flex justify-end gap-2">
          <button onClick={onClose} className="px-4 py-2 rounded-lg border text-gray-700 hover:bg-gray-100 dark:text-white dark:border-gray-600">Cancel</button>
          <button onClick={handleSave} className="px-4 py-2 rounded-lg bg-blue-600 text-white hover:bg-blue-700">Save</button>
        </div>
      </div>
    </div>
  );
};

export default SettingsModal;